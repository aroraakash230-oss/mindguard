# MineGuard Prototype (SIH26024 concept)

## Run it
1. Download and extract `MineGuard_Prototype.zip`.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. No installation or server is required for the demo.

## Interactive features
- Switch between Dashboard, Inspections, Compliance Register, Corrective Actions, Mine Map, and Reports.
- Create an inspection and see it added to the list/dashboard.
- Search inspection and action records.
- Filter compliance requirements by category/status.
- Cycle corrective-action statuses by clicking the status pill.
- Add a sample compliance requirement or corrective action.
- Generate and download a sample CSV report.

## Important limitations
- This is a frontend prototype with sample/demo data.
- Login/authentication, real database, file uploads, GPS, OCR, AI model, email alerts, and real mine-system integrations are not connected.
- The risk flag is explanatory rule-based sample content, not a validated safety prediction.
- The map is an illustrative visual, not a live GIS map.
- Confirm the official SIH26024 wording and requirements before final submission.
