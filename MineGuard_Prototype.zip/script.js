const pages = ["dashboard","inspections","compliance","actions","map","reports"];
const titles = {dashboard:"Dashboard",inspections:"Inspections",compliance:"Compliance Register",actions:"Corrective Actions",map:"Mine Map",reports:"Reports"};
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove("show"),2800)}
function go(page){pages.forEach(p=>$("#page-"+p).classList.toggle("active",p===page));$$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("#crumbTitle").textContent=titles[page]||"Dashboard";$("#sidebar").classList.remove("open");window.scrollTo({top:0,behavior:"smooth"})}
$$(".nav-item").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("#menuToggle").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#notificationBtn").addEventListener("click",()=>toast("You have 3 overdue corrective actions in the demo data."));
const today=new Date();$("#inspectionDate").value=today.toISOString().slice(0,10);
function openInspectionForm(){go("inspections");$("#inspectionFormPanel").hidden=false;$("#findingTitle").focus();$("#inspectionFormPanel").scrollIntoView({behavior:"smooth",block:"start"})}
$("#newInspectionBtn").addEventListener("click",openInspectionForm);
$("#newInspectionBtn").addEventListener("click",()=>{});
$("#closeForm").addEventListener("click",()=>$("#inspectionFormPanel").hidden=true);
$("#cancelForm").addEventListener("click",()=>$("#inspectionFormPanel").hidden=true);
let inspectionId=1049;
$("#inspectionForm").addEventListener("submit",e=>{
 e.preventDefault();
 const mine=$("#mine").value,type=$("#inspectionType").value,inspector=$("#inspector").value,date=$("#inspectionDate").value,title=$("#findingTitle").value,severity=$("#severity").value,category=$("#category").value;
 const dateText=new Date(date+"T12:00:00").toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"});
 const tr=document.createElement("tr");
 tr.innerHTML=`<td>INSP-${inspectionId++}</td><td>${esc(mine)}</td><td>${esc(type.replace(" Inspection",""))}</td><td>${esc(inspector)}</td><td>${dateText}</td><td>${esc(title)}</td><td><span class="status issue">Issues found</span></td>`;
 $("#inspectionRows").prepend(tr);
 $("#inspectionCount").textContent=Number($("#inspectionCount").textContent)+1;
 $("#inspectionCount2").textContent=Number($("#inspectionCount2").textContent)+1;
 const recent=document.createElement("div");recent.className="activity";
 recent.innerHTML=`<div class="activity-icon blue">☑</div><div class="activity-main"><strong>${esc(mine)}</strong><small>${esc(type)} · Just now · ${esc(severity)} priority</small></div><span class="status issue">Issues found</span>`;
 $("#recentInspections").prepend(recent);
 $("#inspectionFormPanel").hidden=true;$("#inspectionForm").reset();$("#inspectionDate").value=today.toISOString().slice(0,10);
 toast("Inspection saved to this prototype.");
});
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("#inspectionSearch").addEventListener("input",()=>filterRows("#inspectionRows",$("#inspectionSearch").value));
function filterRows(selector,q){const query=q.toLowerCase();$$(selector+" tr").forEach(tr=>tr.style.display=tr.innerText.toLowerCase().includes(query)?"":"none")}
$("#categoryFilter").addEventListener("change",filterCompliance);
$("#statusFilter").addEventListener("change",filterCompliance);
$("#complianceSearch").addEventListener("input",filterCompliance);
function filterCompliance(){const cat=$("#categoryFilter").value,stat=$("#statusFilter").value,q=$("#complianceSearch").value.toLowerCase();$$('#complianceRows tr').forEach(tr=>{tr.style.display=(!cat||tr.dataset.category===cat)&&(!stat||tr.dataset.status===stat)&&tr.innerText.toLowerCase().includes(q)?"":"none"})}
$("#actionSearch").addEventListener("input",()=>filterRows("#actionRows",$("#actionSearch").value));
$("#actionRows").addEventListener("click",e=>{const b=e.target.closest(".status-button");if(!b)return;const states=["Pending","In progress","Completed","Overdue"];let i=states.indexOf(b.textContent.trim());let next=states[(i+1)%states.length];b.textContent=next;b.className="status status-button "+({"Pending":"pending","In progress":"progress-status","Completed":"complete","Overdue":"overdue"}[next]);toast("Action status changed to "+next+".")});
function modal(title,text,label,placeholder,onSave){$("#modalTitle").textContent=title;$("#modalText").textContent=text;$("#modalLabel").firstChild.textContent=label;$("#modalInput").value="";$("#modalInput").placeholder=placeholder;$("#modalBackdrop").hidden=false;$("#modalConfirm").onclick=()=>{const val=$("#modalInput").value.trim();if(!val){toast("Please enter a value.");return}onSave(val);$("#modalBackdrop").hidden=true}}
$("#modalClose").onclick=$("#modalCancel").onclick=()=>$("#modalBackdrop").hidden=true;
$("#addRequirementBtn").addEventListener("click",()=>modal("Add compliance requirement","Add a sample requirement to the register. This prototype does not connect to official statutory systems.","Requirement name","e.g. Equipment safety review",val=>{const tr=document.createElement("tr");tr.dataset.category="Safety";tr.dataset.status="Pending";tr.innerHTML=`<td>CR-${String($("#complianceRows").children.length+1).padStart(3,"0")}</td><td><strong>${esc(val)}</strong><small>Added in prototype</small></td><td>Safety</td><td>Mine Manager</td><td>Kusunda Mine</td><td>31 Oct 2026</td><td><span class="status pending">Pending</span></td><td>•••</td>`;$("#complianceRows").prepend(tr);toast("Requirement added.")}));
$("#newActionBtn").addEventListener("click",()=>modal("Create corrective action","Create a demo action from an inspection finding.","Action title","e.g. Repair guard railing",val=>{const tr=document.createElement("tr");tr.innerHTML=`<td>AC-${String($("#actionRows").children.length+1).padStart(3,"0")}</td><td>${esc(val)}</td><td>Kusunda Mine</td><td>Maintenance Team</td><td>10 Oct 2026</td><td><span class="status pending">Medium</span></td><td><button class="status pending status-button">Pending</button></td>`;$("#actionRows").prepend(tr);$("#actionTotal").textContent=Number($("#actionTotal").textContent)+1;toast("Corrective action created.")}));
$("#reportForm").addEventListener("submit",e=>{e.preventDefault();const type=$("#reportType").value,mine=$("#reportMine").value;const csv="Report Type,Mine/Site,Metric,Value\n"+`"${type}","${mine}","Overall compliance","78%"\n`+'"Safety","All sites","Compliance","82%"\n'+'"Environment","All sites","Compliance","76%"\n'+'"Production","All sites","Compliance","85%"\n'+'"Labour","All sites","Compliance","71%"\n'+'"Open corrective actions","All sites","Count","23"\n';const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=type.replaceAll(" ","_")+"_Demo.csv";a.click();URL.revokeObjectURL(url);const item=document.createElement("div");item.className="export-item";item.innerHTML=`<span class="file-icon">CSV</span><div><strong>${esc(a.download)}</strong><small>Generated just now · ${esc(mine)}</small></div><span class="status complete">Available</span>`;$("#recentExports").prepend(item);toast("Demo CSV report downloaded.")});
$("#notificationBtn").title="Notifications";
